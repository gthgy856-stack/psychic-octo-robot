package dev.stark.timelocker;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class TimeLocker extends JavaPlugin implements Listener {

    private long lockedTime;
    private BukkitTask task;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadLockedTime();
        Bukkit.getPluginManager().registerEvents(this, this);
        startTimeLockTask();
        getLogger().info("TimeLocker enabled — all worlds locked to time " + lockedTime);
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        getLogger().info("TimeLocker disabled.");
    }

    private void loadLockedTime() {
        lockedTime = getConfig().getLong("locked-time", 10800L);
    }

    private void startTimeLockTask() {
        if (task != null) task.cancel();

        task = Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (World world : Bukkit.getWorlds()) {
                lockWorld(world);
            }
        }, 0L, 1L);
    }

    private void lockWorld(World world) {
        world.setTime(lockedTime);
        world.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        World world = event.getWorld();
        lockWorld(world);
        getLogger().info("World loaded: " + world.getName() + " — locked to time " + lockedTime);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("timelockstatus")) {
            if (!sender.hasPermission("timelocker.status")) {
                sender.sendMessage("§cNo permission.");
                return true;
            }
            sender.sendMessage("§a[TimeLocker] §fAll worlds locked to time §e" + lockedTime);
            for (World w : Bukkit.getWorlds()) {
                sender.sendMessage("  §7» §f" + w.getName() + " §8| current: §e" + w.getTime());
            }
            return true;
        }

        if (command.getName().equalsIgnoreCase("timelockreload")) {
            if (!sender.hasPermission("timelocker.reload")) {
                sender.sendMessage("§cNo permission.");
                return true;
            }
            reloadConfig();
            loadLockedTime();
            startTimeLockTask();
            sender.sendMessage("§a[TimeLocker] §fReloaded! New locked time: §e" + lockedTime);
            return true;
        }

        return false;
    }
}
